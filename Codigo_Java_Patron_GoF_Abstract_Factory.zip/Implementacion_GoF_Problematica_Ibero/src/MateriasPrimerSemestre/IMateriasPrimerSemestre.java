package MateriasPrimerSemestre;

//Interfaz que se implementa en las clases que crean los paquetes de materias
public interface IMateriasPrimerSemestre {
    void materiaAsignada();
}



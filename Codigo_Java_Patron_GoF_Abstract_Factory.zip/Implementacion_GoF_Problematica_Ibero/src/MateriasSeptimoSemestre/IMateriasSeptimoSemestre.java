package MateriasSeptimoSemestre;


public interface IMateriasSeptimoSemestre {
    void materiaAsignada();
}

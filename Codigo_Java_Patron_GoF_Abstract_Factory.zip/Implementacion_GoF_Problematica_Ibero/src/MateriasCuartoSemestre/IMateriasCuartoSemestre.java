package MateriasCuartoSemestre;


public interface IMateriasCuartoSemestre {
    void materiaAsignada();
}

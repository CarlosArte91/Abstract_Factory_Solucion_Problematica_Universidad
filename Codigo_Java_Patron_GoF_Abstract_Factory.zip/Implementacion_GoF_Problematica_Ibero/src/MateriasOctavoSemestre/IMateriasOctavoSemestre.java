package MateriasOctavoSemestre;


public interface IMateriasOctavoSemestre {
    void materiaAsignada();
}

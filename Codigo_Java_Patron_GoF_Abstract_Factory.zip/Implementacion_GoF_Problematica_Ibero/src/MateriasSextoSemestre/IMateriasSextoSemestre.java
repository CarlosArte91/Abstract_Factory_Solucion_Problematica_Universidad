package MateriasSextoSemestre;


public interface IMateriasSextoSemestre {
    void materiaAsignada();
}

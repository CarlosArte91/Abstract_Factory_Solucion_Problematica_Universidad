package MateriasSegundoSemestre;


public interface IMateriasSegundoSemestre {
    void materiaAsignada();
}

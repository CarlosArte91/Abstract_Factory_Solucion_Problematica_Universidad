package MateriasQuintoSemestre;


public interface IMateriasQuintoSemestre {
    void materiaAsignada();
}

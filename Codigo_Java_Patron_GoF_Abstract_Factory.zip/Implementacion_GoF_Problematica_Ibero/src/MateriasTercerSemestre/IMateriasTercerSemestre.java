package MateriasTercerSemestre;


public interface IMateriasTercerSemestre {
    void materiaAsignada();
}
